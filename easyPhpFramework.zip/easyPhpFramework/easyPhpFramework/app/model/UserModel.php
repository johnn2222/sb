<?php
class UserModel extends model{
    
    public function __construct()
    {        
      parent::__construct();
       $this->model=parent::modelInst();
    }
    
    public function getUser($startPage,$pageLimit){      
    $res=$this->model->Select("select * from user limit " . $startPage.",".$pageLimit);    
     return $res;
    }
    //get count total user
    public function getCountUser()
    {
       $qry=$this->model->Select("select count(*) as COUNT from user");   
       foreach($qry as $res){$res ;};
       return $res->COUNT;
      
    }
    
    public function deleteUser($tbl,$cond=array())
    {
       $res=$this->model->Delete($tbl, $cond);
       if($res):
           SuccMsg("deleted!");
           else:
           ErrMsg('error');
       endif;
       return $res;
    }
    //add user
    public function addUser($tbl,$data)
    {
     if($data)
     {
        $re=$this->model->Insert($tbl, $data); 
        if($re)
              {
                SuccMsg('inserted successful!'); 
               }else{
                    ErrMsg('ERROR!');
                }
     }
     return $re;        
    }
    //get user by id
    public function getUserById($id)
    {
        $res=$this->model->Get('user',array("id"=>$id));
        return $res;
    }
    //update user
    public function updateUser($tbl,$data,$cond)
    {
     $res=$this->model->Update($tbl, $data, $cond); 
     if($res)
        {
            SuccMsg('updated!');   
        }else
            {
            ErrMsg('error');      
        }
        return $res;
    }
}
