<?php
//library class 
class getData extends library{
    var $value;
    public function setValue($string)
    {
        $this->value=$string;
    }

    public function getValue()
    {
        echo "hello how r u?";
    }
 
    
}


