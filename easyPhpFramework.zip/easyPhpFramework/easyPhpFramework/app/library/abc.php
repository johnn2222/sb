<?php

class abc{
    var $value;
    public function setValue1($string)
    {
        $this->value=$string;
    }

    public function getValue1()
    {
        echo $this->value;
    }
 
    
}


