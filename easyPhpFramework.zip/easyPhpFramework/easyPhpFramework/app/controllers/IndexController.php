<?php
/*instruction to use in index function  
 //** ALL LOAD SHOULD BE IN FUNCTION CONSTRUCT 
 * load model: $this->LoadModel('modelName'); and it can be use like this $this->modelName in any function. 
 * load library: $this->LoadLibrary('libName'); and it can be use like this $this->libName in any function. 
 * load helper: $this->LoadHelper('helperName'); and it can be use like this helperName(); in any function.
 * for include SESSION :$this->LoadLibrary('session'); use like this $this->session in any function .
 * **/
/**
 * FOR LOAD ON HTML PAGE : call html page from view folder like this:-
 *  $this->view->render('pageName',$data,1); $data parameter for send vaiable to view file (3)parameter is 1 is for require header footer if need else leave this parameter
 * set $data variable for view page like this $data['msg']="hello"; view file you can use echo $msg;
 * Load single controller css like this $this->view->css="fileName";
 * Load single controller script like this $this->view->script="fileName";
 * Load single controller custom css like this $this->view->CustomCss="whole link rel tag with filename";
 *  
 */
class IndexController extends controller {
    
    //note: do not remove __construct function //
    public function __construct() {      
       parent::__construct();       
        }
      //end 
    
    public function index()
    {           
       $this->view->Title='Welcome to Easyphp Framework';             
       $this->view->render('welcome',$data=null,1);
     
    }
   
}
?>
