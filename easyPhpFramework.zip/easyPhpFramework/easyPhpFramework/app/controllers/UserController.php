<?php
/*instruction to use in index function  
 //** ALL LOAD SHOULD BE IN FUNCTION CONSTRUCT 
 * load model: $this->LoadModel('modelName'); and it can be use like this $this->modelName in any function. 
 * load library: $this->LoadLibrary('libName'); and it can be use like this $this->libName in any function. 
 * load helper: $this->LoadHelper('helperName'); and it can be use like this helperName(); in any function.
 * for include SESSION :$this->LoadLibrary('session'); use like this $this->session in any function .
 * **/
/**
 * FOR LOAD ON HTML PAGE : call html page from view folder like this:-
 *  $this->view->render('pageName',$data,1); $data parameter for send vaiable to view file (3)parameter is 1 is for require header footer if need else leave this parameter
 * set $data variable for view page like this $data['msg']="hello"; view file you can use echo $msg;
 * Load single controller css like this $this->view->css="fileName";
 * Load single controller script like this $this->view->script="fileName";
 * Load single controller custom css like this $this->view->CustomCss="whole link rel tag with filename";
 *  
 */
class UserController extends controller {
    
    //note: do not remove __construct function //
    public function __construct() {      
        parent::__construct();       
      $this->LoadLibrary('session');
      $this->LoadModel('User');
       }
      //end 
    
    public function index()
    {           
       $this->view->Title='All User';
       $page=(@$_GET['page']!='')?@$_GET['page']:1;       
       $data['userCount']=$this->getCountUser();
       $data['page']=$page;
       $data['userResult']=$this->getUser($page);
       $this->view->render('user/manageUser',$data,1);
       
    }
    
    
    public function addUser()
    {
        //get ajax request here
//        if(isset($_REQUEST['name']))
//        {
//            echo "hello hi how r u?";
//            die();
//        }
        
       $this->view->Title='Add User';
        $this->view->render('user/addUser',$data=NULL,1);        
       if(isset($_REQUEST['submit']))
       {          
          $data=$this->post('info');           
          $res=$this->User->addUser("user",$data);
           if($res)
              {
               redirect('User'); 
               }
           
        }
    }
    
    private function getUser($page)
    { $pageLimit=Constant::$PAGE_LIMIT;   
      $startFrom=($page-1)*$pageLimit;
      $res=$this->User->getUser($startFrom,$pageLimit);
      return $res;
    }
    
    
    public function getCountUser()
    {
     return $this->User->getCountUser();
    }
    
    public function editUser()
    {
        $this->view->Title='Edit User';
        $data['action']="edit";        
        $data['userData']=$this->getUserById();
        $this->view->render('user/addUser',$data,1);
         
        
    }
    
    public function updateUser()
    {
     if(isset($_POST['id']))
     {
     $id=$_POST['id'];
     
     $data=$_POST['info'];
     $cond=array("id"=>$id);
     $res=$this->User->updateUser("user",$data,$cond);
        if($res)
        {
           redirect('User');
            
        }
     }
    }
    
    //delete user
    public function DeleteUser()
    {      
       if(isset($_REQUEST['id']))
     {
     $id=$_REQUEST['id'];
     $cond=array("id"=>$id);
      $del=$this->User->deleteUser('user',$cond);
       
      if($del):
          redirect('User');
      endif;
     }
    }
    //get update
    private function getUserById()
    {
     if(isset($_REQUEST['id']))
        {
           $id=$_REQUEST['id'];
          $userData=$this->User->getUserById($id);
        }   
        return $userData;
    }
    
    
}
?>
