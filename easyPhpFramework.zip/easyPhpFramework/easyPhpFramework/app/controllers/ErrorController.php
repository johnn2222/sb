<?php
class ErrorController extends controller{     
    public function __construct() {
        parent::__construct();
    }
    
    function index()
    {
         $this->view->render('error');
    }
   }
?>
