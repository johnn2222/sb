<?php
//Constant define here
class Constant{        
//do not remove these contant
 public static $webroot='http://localhost/easyPhpFramework/app/webroot/';
 public static $siteurl='http://localhost/easyPhpFramework/'; 
 public static $PAGE_LIMIT=25;
   
}

?>
