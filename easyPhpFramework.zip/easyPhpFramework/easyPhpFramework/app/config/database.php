<?php
//db connection class
class database { 
    private static $host='localhost';
    private static $dbname='test';
    private static $user='root';    
    private static $pwd=''; 
    
    
    public function __construct() {          
       // parent::__construct('mysql:host='.$this->host.';dbname='.$this->dbname,$this->user,$this->pwd);
     $this->db=$this->getInstance();
        
    }
    
    
    public static $Instance=null;
    public static function getInstance(){  
        if(!isset(self::$Instance))
        {           
          try{
          self::$Instance=new PDO('mysql:host='.self::$host.';dbname='.self::$dbname,self::$user,self::$pwd);  
              }
          catch (PDOException $e)
          {           
             print "db error!".$e->getMessage(); 
             die();
          }
        }
       return self::$Instance; 
    }
    
    
    public function query($sql)
    { 
        if(isset($sql))
        {   $statementErr=' ERROR: ';
            $sth=$this->db->prepare($sql);      
            $sth->execute(); 
            $err=$sth->errorInfo();
            if(!empty($err))
            {            
                foreach($err as $error)
               {
                 $statementErr.= $error; 
               }             
               if($statementErr==0000)
               {
                  $statementErr=''; 
               }
            }
            
             logger::LogBook(self::$dbname,$sql,$statementErr);
            return $sth;       
        }          
    }
    public function insertId()
    {
        return $this->db->lastInsertId();
    }
    
    public function resultArray($sth)
    {
        if(isset($sth))
        {  
                  
            $res=$sth->fetchAll();
            return $res;
        }
        else{
            echo "query is empty!";
            return false;
        }       
        
    }
    
    public function result($sth)
    {
      if(isset($sth))
         {  
            $res=$sth->fetch(PDO::FETCH_OBJ);
            return $res;
        }
        else{
            echo "query is empty!";
            return false;
        }       
          
    }
	
	public function numRows($sth)
    {          
        if(isset($sth))
         {
            return $sth->rowCount();
        }
        else{
            echo "query is empty!";
            return false;
        }       
    }
    public function resultObject($sth)
    {     
     
        if(isset($sth))
         {  
            $res=$sth->fetchAll(PDO::FETCH_OBJ);
            return $res;
        }
        else{
            echo "query is empty!";
            return false;
        }       
        
        
    }
    
    public function resultAssoc($sth)
    {
        if($sth)
        {   
            $res=$sth->fetchAll(PDO::FETCH_ASSOC);
            return $res;
        }
        else{
            echo "query is empty!";
            return false;
        }       
        
    }
    
       
    public function resultJson($sth)
    {       
        if($sth)
        {   
            $res=$sth->fetchAll(PDO::FETCH_ASSOC);
            $JSON =  json_encode($res);
            return $JSON;
        }
        else{
            echo "query is empty!";
            return false;
        }       
        
    }
    
    //bindig parameter
    public function DataBindQry($qry,$param=NULL)
    {    
        if(isset($qry))
        {
            logger::LogBook($qry);
            $query=$this->db->prepare($qry);
            if(is_array($param))
            {
             foreach($param as $key=>$val)
                {
                 $keys=':'.$key;
                $query->bindParam($keys,$val,PDO::PARAM_STR);            
                }            
            }
            $re=$query->execute();
            return  $re;           
       }
    }
}
?>