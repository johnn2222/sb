<?php 
//define route controller here which is load first or default;
 $route['default_controller'] = array('controller'=>'Index','action'=>'index'); //set as default controller and method
?>