<?php
//input library, helpers in autoloaded your controller
$autoload['libraries']=array();
$autoload['helpers']=array('myHelper');
$autoload['models']=array();
?>