<?php
$timezone = "Asia/Calcutta";
if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);

//error debugging
ini_set('display_errors',1);
//end
//logbook 

$config['logger']=true;
$config['secretKey']="abce12334556jdhfdhsas"; //secret key for token if you need.

$config['encryptKey']="aes123";  //anything you can put your encrypt key its need when you encrypt any data use encrypt decrypt from this key.
/*
 * for encrypt data:
 * $block=128; //default this is block size
 * $aes=new encrypt(json_encode($data),$config['encryptKey'],$block);
   $yourData=$aes->encrypt();
 * 
 */

/*
 * for decrypt data:
 * $block=128; //default this is block size
 * $aes=new encrypt($data,$config['encryptKey'],$block);
   $yourData=$aes->decrypt();
 * 
 */




//end
?>
