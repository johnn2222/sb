<!DOCTYPE html>
<html>
  <head>
    <?php
    //**do not remove configHead();**//
    $this->configHead();
    $this->script('bootstrap.min');
    $this->css('bootstrap.min');             
     ?>
  </head>
  <body>

  <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#" style="color:#a94442;">EasyPhp Framework!</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="<?php echo siteUrl();?>">Home</a></li>
      <li><a href="<?php echo siteUrl()."User";?>">User</a></li>     
    </ul>
  </div>
</nav>

