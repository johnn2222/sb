<div class="footer">
<hr />
    <footer>        
    <center><span style="color:#a94442;">  2016 &copy; EasyPhp Framework Ver.1.0 </span></center>
    </footer>
  </body>
</html>
</div>

