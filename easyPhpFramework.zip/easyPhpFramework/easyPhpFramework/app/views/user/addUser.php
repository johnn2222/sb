<div class="container">
    <?php 
    GetMsg(); 
    $Action=isset($action)?$action:'';          
        switch($Action)
        {
        case'edit': 
        if(isset($userData))
        {
          foreach($userData as $res){
           $res;   
          }  
        }
    ?>
    <div class="container">
    <form method="post" action="<?php echo siteUrl().'User/updateUser';?>">
        <input type="hidden" value="<?php echo $res->id;?>" name="id">
        <div class="col-lg-2">
            <label>Name</label>
        </div>  
        <div class="col-lg-10">            
            <input type="text" name="info[name]" value="<?php echo $res->name;?>" class="form-control">
        </div>
        
         <div class="col-lg-2">
            <label>Email</label>
        </div>
        <div class="col-lg-10">            
        <input type="text" name="info[email]" value="<?php echo $res->email;?>" class="form-control">
        </div>
        
        
         <div class="col-lg-2">
            <label>Address</label>
        </div>
        <div class="col-lg-10">            
        <input type="text" name="info[address]" value="<?php echo $res->address;?>" class="form-control">
        </div>
        
         <div class="col-lg-2">
            <label>Mobile</label>
        </div>
        <div class="col-lg-10">            
        <input type="text" name="info[mobile]" value="<?php echo $res->mobile;?>" class="form-control">
        </div>
        <div class=" col-lg-push-2 col-lg-10">            
            <input type="submit" name="submit" value="Update" class="btn btn-primary">
        </div>
        
      </form>
        <?php break;
        default:?>        
        <form method="post" action="<?php echo siteUrl().'User/addUser';?>">
        <div class="col-lg-2">
            <label>Name</label>
        </div>  
        <div class="col-lg-10">            
        <input type="text" name="info[name]" class="form-control">
        </div>
        
         <div class="col-lg-2">
            <label>Email</label>
        </div>
        <div class="col-lg-10">            
        <input type="text" name="info[email]" class="form-control">
        </div>
        
        
         <div class="col-lg-2">
            <label>Address</label>
        </div>
        <div class="col-lg-10">            
        <input type="text" name="info[address]" class="form-control">
        </div>
        
         <div class="col-lg-2">
            <label>Mobile</label>
        </div>
        <div class="col-lg-10">            
        <input type="text" name="info[mobile]" class="form-control">
        </div>
        <div class=" col-lg-push-2 col-lg-10">            
            <input type="submit" name="submit" value="Add" class="btn btn-primary">
        </div>
        
      </form>
        <?php break; }
    ?>

</div>