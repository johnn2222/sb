  
    <div class="container">
        <?php GetMsg();?>
        <div class="row">
           <div class="col-lg-12">
               <button onclick="sendData();">Send Ajax</button>
               <span class="col-lg-2 pull-right"><a href="<?php echo siteUrl()."User/addUser";?>" class="btn btn-primary">Add User</a></span>
        </div>
        </div>
       
        <table class="table" width="100%">
            <thead>
            <tr>
            <th>Sno.</th>
            <th>User Id</th>
            <th>Name</th>
            <th>Address</th>
            <th>Email</th>
            <th>Mobile</th>
            <th colspan="2">Action</th>
            <tr>
            </thead>
            
            <tbody>
                <?php if(isset($userResult))
                {
                 $sno=1;          
                 
                 foreach($userResult as $row){ ?>
                <tr>
                 <td><?php echo $sno++;?></td>
                  <td><?php echo $row->id;?></td>
                <td><?php echo $row->name;?></td>
                <td><?php echo $row->address;?></td>
                <td><?php echo $row->email;?></td>
                <td><?php echo $row->mobile;?></td>
                <td><a href="<?php echo siteUrl().'User/editUser?id='.$row->id;?>" class="btn btn-default">Edit</a></td>
                <td><a href="<?php echo siteUrl().'User/DeleteUser?id='.$row->id;?>" class="btn btn-danger">Delete</a></td>
                </tr>
                 <?php } }?>
            </tbody>
            <tr> 
                <td colspan="7">
            <?php generatePaginationLink($userCount,Constant::$PAGE_LIMIT,$page);?>
                </td>
            </tr>
        </table>    
</div>
<?php  $this->script('jquery-1.8.3.min');?>
<script>
    function sendData(){
        $.ajax({
           type:'POST',
           url:'<?php echo siteUrl()."User/addUser";?>',
           data:'name=sunil',
           success:function($data)
           {
            alert($data);   
           }
        });
    }
</script>