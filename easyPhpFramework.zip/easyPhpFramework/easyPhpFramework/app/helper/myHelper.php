<?php
if(session_id()=="")
    {  
      ob_start();
      session_start(); 
     }
       //set success msg      
    function SuccMsg($msg)
    {
       if(isset($msg))
       {
           
         $_SESSION['SuccMsg']=$msg;  
       }
    }

//set error msg
   
    function ErrMsg($msg)
    {
       if(isset($msg))
       {
           if(session_id()=="")
           {  
               ob_start();
              session_start(); 
           }
         $_SESSION['ErrMsg']=$msg;  
       }
    }

//get msg

    function GetMsg()
    {
      if(isset($_SESSION['ErrMsg']))
      {
       echo '<div class="alert alert-danger" id="ErrMsg">'.$_SESSION['ErrMsg'].'</div>';  
       unset($_SESSION['ErrMsg']);
      }
      
      if(isset($_SESSION['SuccMsg']))
      {
       echo '<div class="alert alert-success" id="SuccMsg">'.$_SESSION['SuccMsg'].'</div>';  
       unset($_SESSION['SuccMsg']);
      }
      
    }

 ?>          
