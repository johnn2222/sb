<?php 
ob_start();
define('APPPATH',__DIR__."/app/");
define('SYSTEMPATH',__DIR__."/system/");
define('MODEL','Model');
define('CONTROLLER','Controller');
//require_once(APPPATH.'config/config.php'); //include Config here
require_once(APPPATH.'config/Constant.php'); //include Constant here
require_once(SYSTEMPATH.'lib/logger.php'); //include Logger here
require_once(APPPATH.'config/database.php'); // include database here
require_once(SYSTEMPATH.'lib/helpers.php'); // base helper
//load core lib  class here
    function autoLoad($className)
    {
       $coreFile='';
       $coreFile=SYSTEMPATH.'lib/'.$className.".php";
       if(file_exists($coreFile))
       {
        require_once($coreFile);        
       }
    }
    spl_autoload_register('autoLoad');
//end
    $app=new bootstrap();
    
?>