<?php
//base controller initilization
class errors{ 
  
    public function __construct($strings=NULL)
    { 
        echo $strings;
        exit();
    }	  
}
?>