<?php
//Constant define here
class logger{
     public static function LogBook($dbName,$string,$dbError)
    {  
       require(APPPATH."config/config.php");   
       if($config['logger']==true){       
        $filePath=APPPATH."config/logbook.txt";
		 exec("chmod -R 777 ".APPPATH."config/logbook.txt");
        $file=fopen($filePath,"a");    
        exec("chmod -R 777 $filePath "); 
        $currentDate=date('Y-m-d h:i:s',time());
        fwrite($file,$currentDate ." Database: ".$dbName. " Execute Query: ".$string . $dbError."\n");
        fclose($file);       
       }
        
    }      
      
}
?>
