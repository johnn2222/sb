<?php
class route{
   public function CheckRoute()
    {
       require_once(APPPATH.'config/routes.php');
       if(is_array($route))
       {
           $defaultCtrl=$route['default_controller']['controller'];          
           $defaultAction=$route['default_controller']['action'];          
           $filename=APPPATH.'controllers/'.$defaultCtrl.CONTROLLER.".php";
           $CtrlName=$defaultCtrl.CONTROLLER;
           
           if(file_exists($filename))
               {
               require_once ($filename);              
               $defaultController= new $CtrlName();
               if(method_exists($defaultController, $defaultAction))
               {
                 $defaultController->$defaultAction();
               }
               else{                 
                  new errors('this ('.$defaultAction.') action was not found <br> check your route app/config/routes.php');                   
                 
               }
           }
           else{
               new errors('this ('.$defaultAction.') Controller was not found <br> check your route app/config/routes.php');
             
                }
           
           }
       }          
}    
?>