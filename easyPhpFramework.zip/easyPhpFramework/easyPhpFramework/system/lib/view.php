<?php 
class view{   
   public $Title="Untitled";
   public $MetaUnicode='UTF-8';
   public $script;
   public $css;
   public $CustomCss;
   public $MetaDescription;
   public $MetaKeyword;  
 
    public function __construct() {
      $this->db=new database();
      $this->session=new session();
      $this->model =new model();
      }
    
   
    public function render($viewName,$data=NULL,$hf=NULL)
    {  
       if(isset($data)){
        foreach($data as $key=>$val)
        {
            $$key=$val;
        }
       }
         $viewFile=APPPATH."views/".$viewName.".php";
        if(file_exists($viewFile))
        {            
            if($hf)
            {
            require_once(APPPATH."views/layouts/header.php");
            require_once $viewFile;
            require_once(APPPATH."views/layouts/footer.php");
            }
            else{
              require_once $viewFile;  
            }
        }
        else{
            require_once(APPPATH."views/layouts/header.php");
           new errors("this ". $viewName . "view file is not exists in views folder!");
            require_once(APPPATH."views/layouts/footer.php");
            }         
    }
    
     public function ConfigHead()
    {
       //call view utils function
         $this->loadJsCss();
         $this->loadMetas();
        //end  
    }
    public function loadJsCss()
    {
        if(isset($this->script))
        {  
      
             if(strstr($this->script,","))
             {
            $fileExp=exolode(",",trim($this->script));            
                          
               foreach(rtrim($fileExp,",") as $jsFile)
               {
                 echo '<script src="'.Constant::$webroot."js/".$jsFile.".js".'" type="text/javascript"></script>'."\n";
               }
             }
            else{
             echo '<script src="'.Constant::$webroot."js/".$this->script.".js".'" type="text/javascript"></script>'."\n";
            }
           }  
           
    
        if(isset($this->css))
        {  
            if(strstr($this->css,","))
             {
                
            $fileExp=explode(",",trim($this->css));    
          
            if(is_array($fileExp))
            {               
               foreach($fileExp as $cssFile)
               {
                 echo '<link rel="stylesheet" type="text/css" href="'.Constant::$webroot."css/".$cssFile.".css".'">'."\n";
               }
            }
           }
            else{
             echo '<link rel="stylesheet" type="text/css" href="'.Constant::$webroot."css/".$this->css.".css".'">'."\n";   
            }               
            
        }
    
      if(is_string($this->CustomCss))
      {
         echo $this->CustomCsseFile."\n"; 
      }
    
}
    //meta unicode
    public function loadMetas()
    {  
        if(isset($this->MetaUnicode))
        {
         echo '<meta charset="'.$this->MetaUnicode.'">'."\n";
        }
    
        //title
        if(isset($this->Title))
        {
         echo '<title>'.$this->Title.'</title>'."\n";         
        }
    //meta keywords
    
        if(isset($keyword)){
    echo'<meta name="keywords" content="'.$keyword.'">'."\n";
        }
       
    
    //meta Description
        if(isset($this->MetaDescription))
        {
     echo'<meta name="description" content="'.$this->MetaDescription.'">'."\n"; 
        }
   
    
               
    }
    
    //single load
    public function script($file=NULL)
    {
        if(isset($file))
        {  
      
             if(strstr($file,","))
             {
            $fileExp=explode(",",trim($file));            
                          
               foreach($fileExp as $jsFile)
               {
                 echo '<script src="'.Constant::$webroot."js/".$jsFile.".js".'" type="text/javascript"></script>'."\n";
               }
             }
            else{
             echo '<script src="'.Constant::$webroot."js/".$file.".js".'" type="text/javascript"></script>'."\n";
            }
           }   
    }
    public function css($file=NULL)
    {
        
        if(isset($file))
        {  
            if(strstr($file,","))
             {
            $fileExp=explode(",",trim($file));
          
            if(is_array($fileExp))
            {   
               foreach($fileExp as $cssFile)
               {
                 echo '<link rel="stylesheet" type="text/css" href="'.Constant::$webroot."css/".$cssFile.".css".'">'."\n";
               }
            }
           }
            else{
             echo '<link rel="stylesheet" type="text/css" href="'.Constant::$webroot."css/".$file.".css".'">'."\n";   
            }               
            
        }
    }
    public function CustomCss($cutomeFile=NULL)
    {
      if(is_string($cutomeFile))
      {
         echo $cutomeFile."\n"; 
      }
    }
    
    //meta unicode
    public function MetaUnicode($utf=NULL)
    {  
        if(isset($utf))
        {
         echo '<meta charset="'.$utf.'">'."\n";
        }
    }
    //meta keywords
    public function MetaKeyword($keyword=null)
    {
        if(isset($keyword)){
    echo'<meta name="keywords" content="'.$keyword.'">'."\n";
        }
    }    
    
    //meta Description
    public function MetaDescription($metaDesc=NULL)
    {
        if(isset($metaDesc))
        {
     echo'<meta name="description" content="'.$metaDesc.'">'."\n"; 
        }
    }
    //title
    public function Title($title=NULL)
    {
        if(isset($title))
        {
         echo '<title>'.$title.'</title>'."\n";         
        }
        else{
         echo '<title>Untitled</title>';   
        }
        
    }
}
?>