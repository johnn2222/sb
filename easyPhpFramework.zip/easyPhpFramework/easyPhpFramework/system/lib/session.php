<?php
class session{
    public function __construct() {
        if(session_id()=="")
        {
            ob_start();
            session_start();
        }
    }
 var $sessionData=array(); 

    public function writeSessionData($data=array(),$val=''){
        
        if(is_string($data))
        {   
          $_SESSION[$data]=$val;  
        }
        else{
        if(count($data)>0)
        {
            for($i=0;$i<count($data);$i++)
            {
            foreach($data[$i] as $key=>$val)
            {
                $_SESSION[$key]=$val;
               
            }
           }
        }
       } 
    }
    public function setData($data=array(),$val='')
    {       
        if(is_string($data))
        {
           $this->writeSessionData($data,$val);
        }
        else{
            if(count($data)>0)
            {
              foreach($data as $key=>$val)
              {
               $this->sessionData[]=array($key=>$val);   
              }
            }
        }        
        $this->writeSessionData($this->sessionData);
      
    }
    
    public function getData($keyName=NULL)
    {   
        if($keyName!=NULL)
        {
            if(isset($_SESSION[$keyName]))
            {
              return $_SESSION[$keyName];  
            }
        }
        else{         
         return $_SESSION;
         }
    }
	
    //destroy all session
    public function destroy()
    {
        session_destroy();
    }
    
    //unset session
    public function unsetData($key)
    {
        if(isset($_SESSION[$key]))
        {
        unset($_SESSION[$key]);
        return true;
        }
        else{
            return false;
        }
        
    }
    
    //check session isset
    public function Set($key=NULL)
    {
        if($key!=NULL){
            if(isset($_SESSION[$key]))
            {
                return true;
            }
            else{
            return false;
            }
        }
        elseif($key==""){
           if(isset($_SESSION))
           {
             return true;  
           }else{
               return false;
           }
        }
        
        
    }
}

?>