<?php
//base controller initilization
class bootstrap{ 
  
    public function __construct()
    {        
        if(isset($_GET['url']))
       {                     
         $uri=$this->getUri($_GET['url']);               
         if($uri[0])
         {            
         $fileName=APPPATH."controllers/".$uri[0].CONTROLLER.".php";           
            if(file_exists($fileName))
            { 
                require $fileName;                
                $ctrlName=$uri[0].CONTROLLER;
                $controller= new $ctrlName();
                
                if(isset($uri[1]))
                {
                   
                    $fileName2=APPPATH."controllers/".$uri[0]."/".$uri[1].CONTROLLER.".php";                     
                    if(method_exists($controller, $uri[1]))
                    {                       
                    $controller->{$uri[1]}();   
                    }else{                         
                        redirect('Error');
                    }
                }   
                else{                    
                    if(method_exists($controller, "index"))
                    {  
                       $controller->index();
                    }
                    else{
                    new errors("index method is not define in this controller!");    
                    }
                }
                            
            }
            elseif(file_exists($fileName2))
            {                
                require $fileName2;  
                $ctrlName=$uri[1].CONTROLLER;
                $controller= new $ctrlName();       
                if(isset($uri[2]))
                {
                    if(method_exists($controller, $uri[2]))
                    {
                        $controller->{$uri[2]}();
                    }
                    else{
                        new errors("(".$uri[2].") this method is not exist in this controller!");
                      }
                    
                }
                else{                 
                    if(method_exists($controller, "index"))
                    {  
                       $controller->index();
                    }
                }
            }
            else{               
                redirect('Error');              
            }
         }        
       
        
      }
         else{
             //default route checking here
             $route=new route();
             $route->CheckRoute();
          }
        
  }
    
    public function getUri($url)
    {
        if($url)
        {
          $trim=rtrim($url,"/");  
          $expUri=explode("/",$url);          
        }
        else{
              return false;
        }        
        return $expUri;      
        
    }
}
?>