<?php
//library base class
class library{
    public function __construct() {
        $this->db= new database();
        $this->session=new session();
        $this->model =new model();        
    }
}
?>