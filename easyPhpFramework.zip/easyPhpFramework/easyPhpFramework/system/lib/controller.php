<?php
//base controller
class controller{     
    protected $view;   
    private static $instance;
    public function __construct() {        
        self::$instance =& $this;
    //for view file
     $this->view= new view();
     // for database
     $this->db=new database();
   //autoload
     require_once(APPPATH.'config/AutoLoad.php'); //auto load  
     require_once(APPPATH.'config/config.php'); //config file 
     $this->config=$config;
     $this->autoload=$autoload; 
    
     $this->AutoLoadUtils();
    //autoload end/
    }
    public function AutoLoadUtils()
    {
        //autoload model     
        if(!empty($this->autoload['models']))
        {
        foreach($this->autoload['models'] as $models)
            {                   
              if($models!="")
               { 
                  $Models=$models.MODEL;
                  $modelFile=APPPATH."model/".$models.MODEL.".php";
                  if(file_exists($modelFile))
                   {                      
                   require_once $modelFile;
                   $this->$models=new $Models();                                                                   
                     }
                }                             
              }
        }
        //end autoload model
        
        //autoload library
        if(!empty($this->autoload['libraries']))
          {           
            foreach($this->autoload['libraries'] as $lib)
             {
               if($lib!="")
                {                   
                  if($lib=="session")
                    {                       
                     $this->$lib= new $lib(); 
                      }
                    else{                
                     $liblFile=APPPATH."library/".$lib.".php";
                      if(file_exists($liblFile))
                         { require_once $liblFile;
                          $this->$lib=new $lib();                                                             
                          }                          
                         }
                      }                
                    }
                 }
    //end autoload library
      //load autoload library here
                  if(!empty($this->autoload['helpers']))
                    {                                          
                        foreach($this->autoload['helpers'] as $helper)
                        {
                            if($helper!="")
                            {
                         $helperFIle=APPPATH."helper/".$helper.".php";                     
                                if(file_exists($helperFIle)){
                                require_once $helperFIle;                                   
                                }                     
                            }
                        }                
                    } 
           //end autoload helpers         
    }
        
   public function LoadLibrary($libname){       
            if(isset($libname))
            {    
             if(!empty($this->autoload['libraries']))  
             {                 
                 foreach($this->autoload['libraries'] as $autoLib)
                 {
                  if($libname!=$autoLib && $libname!="session")
                  {             
                $libFile=APPPATH."library/".$libname.".php";
                if(file_exists($libFile))
                  {
                   require_once $libFile;
                   $this->$libname=new $libname();                                                             
                  }
                  else{
                    new errors("this (" .$libname . ") library was not found!");  
                  }
                } 
            }
          }else{
              
              if($libname=="session")
              {             
                $this->$libname=new $libname();
              }
              else{                  
              $libFile=APPPATH."library/".$libname.".php";
                if(file_exists($libFile))
                  {
                   require_once $libFile;
                   $this->$libname=new $libname();                                                             
                  }
                  else{
                    new errors("this (" .$libname . ") library was not found!");  
                  }
              } 
          }
          
   } 
  }
    //end library
    
    public function LoadModel($modelName){
          if(isset($modelName))
            {
            if(!empty($this->autoload['models']))
            {
              foreach($this->autoload['models'] as $autoMod)
              {
               if($modelName!=$autoMod && $modelName!="")
               {              
                $Models=$modelName.MODEL;
                 $modelFile=APPPATH."model/".$Models.".php";
                  if(file_exists($modelFile))
                   {                      
                   require_once $modelFile;
                   $this->$modelName=new $Models();                                                                   
                     }
                  else{
                    new errors("this (" .$modelName . ") Model was not found!");  
                 }
           } 
          }
        } else{
            $Models=$modelName.MODEL;
                 $modelFile=APPPATH."model/".$Models.".php";
                  if(file_exists($modelFile))
                   {                      
                   require_once $modelFile;
                   $this->$modelName=new $Models();                                                                   
                     }
                  else{
                    new errors("this (" .$modelName . ") Model was not found!");  
                 }
        }  
     }
   }
    //end model
    public function LoadHelper($helperName){
        if(isset($helperName))
        {
        if(!empty($this->autoload['helpers']))
            {
              foreach($this->autoload['helpers'] as $autoHelp)
              {
               if($helperName!=$autoHelp && $helperName!="")
               {
               $helperFIle=APPPATH."helper/".$helperName.".php";
                if(file_exists($helperFIle))
                {
                require_once $helperFIle;
                }
                else{
                 new errors("this (" .$helperName . ") Helper was not found!");  
                }
              }
             }
           } else{
               $helperFIle=APPPATH."helper/".$helperName.".php";
                if(file_exists($helperFIle))
                {
                require_once $helperFIle;
                }
                else{
                 new errors("this (" .$helperName . ") Helper was not found!");  
                }
           }
    }  
 }
 
    //post request
    public function post($key=NULL)
    {
        if($key!=NULL)
        {    
            if(isset($_POST[$key]))
            {    $postStr='';   
            
                if(is_string($_POST[$key])){
                    $postStr=htmlentities(addslashes(trim($_POST[$key])), ENT_QUOTES, 'UTF-8');
                    //UTF-8', 'ISO-8859-1//TRANSLIT//IGNORE
                    //$postStr=iconv('UTF-8', 'ISO-8859-1', $string);
                   
                    return $postStr;
                   }
                   else{
                        if(is_array($_POST[$key]))
                        {
                        $postField=array();   
                        foreach($_POST[$key] as $key=>$val)
                        {                        
                        $postVal=htmlentities(addslashes(trim($val)), ENT_QUOTES, 'UTF-8');                        
                          //$postVal=iconv('UTF-8', 'ISO-8859-1', $postValData);
                          $postField[$key]=$postVal;
                        }
                        return $postField;  //array return with sanitize data
                        }
                   }            
            }
            
          
        }
        else{
            if(isset($_POST))
            {
                return true;
            }
            else{
                return false;
            }
         }
    }
    
    //get data
    public function get($key=NULL)
    {
        if($key!=NULL)
        {    
            if(isset($_GET[$key]))
            {    $getStr='';   
            
                if(is_string($_GET[$key])){
                    $getStr=htmlentities(addslashes(trim($_GET[$key])), ENT_QUOTES, 'UTF-8');
                    //UTF-8', 'ISO-8859-1//TRANSLIT//IGNORE
                    //$postStr=iconv('UTF-8', 'ISO-8859-1', $string);                   
                    return $getStr;
                   }
                   else{
                        if(is_array($_GET[$key]))
                        {
                        $getField=array();   
                        foreach($_GET[$key] as $key=>$val)
                        {                        
                        $getVal=htmlentities(addslashes(trim($val)), ENT_QUOTES, 'UTF-8');                        
                          //$postVal=iconv('UTF-8', 'ISO-8859-1', $postValData);
                          $getField[$key]=$getVal;
                        }
                        return $getField;  //array return with sanitize data
                        }
                   }            
            }
            
          
        }        
    }
}
?>