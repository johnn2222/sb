<?php
class model{    
    public static $ModelInstance=null;
    function __construct() {    
      $this->db=new database();
       }        
       
       public static function modelInst()
       {
           if(!isset(self::$ModelInstance)){
          self::$ModelInstance=new model(); 
          return self::$ModelInstance;
           }
       }
    //insert function
    public function Insert($tbl,$data=array())
    {
       $res='';
      if($data && $tbl)
      {        
          $dataValue='';
          $keyName='';
          if(count($data)>0){
            foreach($data as $key=>$val)
            {          
               $keyName.= "`".$key."` ,";                         
               $values=addslashes(trim($val));
               $dataValue.= "'".$values."' ,";
              
            } 
             $dataSet=rtrim($dataValue,",");
            $keys=rtrim($keyName,",");
       $qry="INSERT INTO " . $tbl . "({$keys}) values({$dataSet})";  
       $res=$this->db->query($qry);      
        }      
      } 
      return $res;        
    }
    
    public function Get($tblName,$cond=NULL)
    {
        if(isset($tblName))
        {
           $condition='';
            if(is_string($tblName) && $cond==NULL)
              {              
                $sql="SELECT * FROM {$tblName}";           
              }           
            elseif(!empty($tblName) && !empty($cond)){
              $where='';
               if(count($cond)>0)
                  {
                   foreach($cond as $key=>$val)
                    {
                    $where.="`".$key."`="."'".addslashes($val)."'"  .  " AND";   
                    } 
                    $condition=" WHERE " .rtrim($where,"AND");
                  }
            }
            $sql="SELECT * FROM {$tblName} {$condition}";
            $query=$this->db->query($sql);
            $res=$this->db->resultObject($query); 
          }
         
          return $res;
        }
   
    //select custom statement and its return object array
    public function Select($qry)
    {
        if(isset($qry))
        {
            $query=$this->db->query($qry);
            $res=$this->db->resultObject($query); 
        }
        return $res;
    }
    
    //for delete 
     public function Delete($tblName,$cond)
     {
      if(isset($tblName))  
      {   
         
          if(is_array($cond)){
            $setCond='';
            foreach($cond as $key=>$val)
            {
            $setCond.="`".$key."`="."'".$val."' " ." AND";
            }
            $where="WHERE " .rtrim($setCond,"AND");
            $delete="DELETE FROM {$tblName} {$where}";
          }
         
          $qry=$this->db->query($delete);
      }
      return $qry;
    }
    
    //for update
    public function Update($tblName,$data,$cond)
    {
       
       if(isset($tblName) && isset($data) && isset($cond))  
       {          
          if(is_array($data) && is_array($cond)){
            $field='';
            $Where='';
            foreach($data as $key=>$val)
            {
            $field.="`".trim($key)."`="."'".  addslashes(trim($val))."' ,";
            }            
            foreach($cond as $Wkey=>$Wval)
            {
            $Where.="`".trim($Wkey)."`="."'".addslashes(trim($Wval))."' AND";
            }            
            $clause=rtrim($field,","). " WHERE " .rtrim($Where,"AND");            
            $sql="UPDATE  {$tblName} SET {$clause}";
            $res=$this->db->query($sql);                    
          }          
      }
      return $res; 
    }

    //update data with parameter binding
    public function UpdateBindData($tblName,$data=array(),$cond=array())
    {
       if(isset($tblName) && isset($data) && isset($cond))  
       {          
          if(is_array($data) && is_array($cond)){
            $field='';
            $Where='';
            foreach($data as $key=>$val)
            {
            $field.="`".trim($key)."`=".":".  addslashes(trim($key))." ,";
            }
            
            foreach($cond as $key=>$val)
            {
            $Where.="`".trim($key)."`="."'".addslashes(trim($val))."' AND";
            }            
            $clause=rtrim($field,","). " WHERE " .rtrim($Where,"AND");            
            $sql="UPDATE  {$tblName} SET {$clause}";
            $res=$this->db->DataBindQry($sql,$data);           
          }
          
      }
      return $res; 
    }
    
    //insert record with binding parameter
     public function InsertBindData($tbl,$data=array())
    {
      $res='';
      if($data && $tbl)
      {   $dataValue='';
          $keyName='';
          if(count($data)>0){
            foreach($data as $key=>$val)
            {          
               $keyName.= "`".$key."` ,";                         
               $values=addslashes(trim($val));
               $dataValue.= "'".$values."' ,";
              
            } 
             $dataSet=rtrim($dataValue,",");
            $keys=rtrim($keyName,",");
       $qry="INSERT INTO " . $tbl . "({$keys}) values({$dataSet})";   
       $res=$this->db->DataBindQry($qry,$data); 
          }
      }      
      return $res;        
    }  
}
?>