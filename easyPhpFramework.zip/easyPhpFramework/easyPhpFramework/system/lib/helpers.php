<?php
//for redirect url
 function redirect($url)
{     ob_start();
     if(strtolower($url)=="home")
    { 
        $redirectUrl=Constant::$siteurl;
    }
    else{
        $redirectUrl=Constant::$siteurl.$url;
    }     
     header('location:'.$redirectUrl);
     ob_get_clean();
    exit(); 
}

function siteUrl()
{
return Constant::$siteurl;    
}

function printData($data)
{
    echo "<pre>";
    print_r($data);
    echo "</pre>";
}

//pagination
function generatePaginationLink($Totalcount,$limit, $page,$param=NULL)
{  
    if(isset($param))
        {
        $param=$param."&";
        }else{$param="";}
    $numOfPages=ceil($Totalcount/$limit);
	$l = ($page > 1) ? '?'.$param.'page=' . ($page - 1) : 'javascript:void(0)';
	$pagination = "";
	$pagination.= "<nav class='pag-nav'><ul class=pagination pagination-sm>";
	$preDisplay = ($page == 1) ? 'disabled' : '';
	$pagination.= "<li class='" . $preDisplay . "'><a href='" . $l . "' aria-label='Previous'>";
	$pagination.= "<span aria-hidden=true>&laquo;</span></a></li>";
	for ($i = 1; $i <= $numOfPages; $i++) {
		$idisplay = ($page == $i) ? 'active' : '';
		$pagination.= "<li class='" . $idisplay . "'><a href='?".$param."page=$i'>$i</a></li>";
	}

	$p = ($page < $numOfPages) ? '?page=' . ($page + 1) : 'javascript:void(0)';
	$nextDisplay = ($page == $numOfPages) ? 'disabled' : '';
	$pagination.= "<li class='" . $nextDisplay . "'><a href='" . $p . "' aria-label='Next'><span aria-hidden=true>&raquo;</span></a></li>";
	$pagination.= "</ul></nav>";
	echo $pagination;
}

//end redirect url
?>